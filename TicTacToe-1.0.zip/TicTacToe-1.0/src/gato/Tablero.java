package gato;

public class Tablero {
  
    /** Creates a new instance of Tablero */
    public Tablero() {
        
    }
    
}
